<?php
$name =  $_POST['name'];
$email =  $_POST['email'];
$subject =  $_POST['subject'];
$message =  $_POST['message'];

$mailheader = "From:".$name."<" .$email.">\r\n";

$recipient = "thebookherd@gmail.com"

mail($recipient, $subject, $message, $mailheader)
or die("Error!");

echo'
<!DOCTYPE html>
<html>
<head>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Gochi+Hand&family=Pangolin&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Gochi+Hand&family=Lilita+One&family=Pangolin&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/style.css">
<title>Home Page - Book Herd</title>
</head>
<body style="background-color: #fffaeb">
<div class="header">
  <a href="bookherd.html" class="logo">
  <img src="logo.png" width="209" height="32" border="0"/>
  </a>
  <div class="header-right">
    <a href="home page.html">&nbsp Home &nbsp </a>
    <a href="library.html">&nbsp E-Library &nbsp </a>
    <a href="puzzles.html">&nbsp Puzzles &nbsp </a>
    <a class="active" href="about us.html">&nbsp About Us &nbsp </a>
    <a href="products.html">&nbsp Products &nbsp </a>
  </div>
</div>

<div class="ty">
<h1>Thank you for sending us an email! We will get back to you as soon as possible.</h1>
     <a href="about us.html">&nbsp Go back to About Us page &nbsp </a>
 <a href="home page.html">&nbsp Go pack to Home page &nbsp </a>
</div> 
</body>
</html>
';

?>